﻿namespace ExaminationSystem
{
    partial class frmExam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubmit = new System.Windows.Forms.Button();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.lblQ10 = new System.Windows.Forms.Label();
            this.lblQ9 = new System.Windows.Forms.Label();
            this.lblQ8 = new System.Windows.Forms.Label();
            this.lblQ7 = new System.Windows.Forms.Label();
            this.lblQ6 = new System.Windows.Forms.Label();
            this.lblQ5 = new System.Windows.Forms.Label();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.lblQ2 = new System.Windows.Forms.Label();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(890, 475);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(112, 34);
            this.btnSubmit.TabIndex = 51;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(820, 428);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(182, 33);
            this.comboBox10.TabIndex = 50;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(820, 385);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(182, 33);
            this.comboBox9.TabIndex = 49;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(820, 342);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(182, 33);
            this.comboBox8.TabIndex = 48;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(820, 297);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(182, 33);
            this.comboBox7.TabIndex = 47;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(820, 251);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(182, 33);
            this.comboBox6.TabIndex = 46;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(820, 207);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(182, 33);
            this.comboBox5.TabIndex = 45;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(820, 163);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(182, 33);
            this.comboBox4.TabIndex = 44;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(820, 116);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(182, 33);
            this.comboBox3.TabIndex = 43;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(820, 74);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(182, 33);
            this.comboBox2.TabIndex = 42;
            // 
            // lblQ10
            // 
            this.lblQ10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ10.AutoSize = true;
            this.lblQ10.Location = new System.Drawing.Point(124, 431);
            this.lblQ10.Name = "lblQ10";
            this.lblQ10.Size = new System.Drawing.Size(69, 25);
            this.lblQ10.TabIndex = 41;
            this.lblQ10.Text = "label20";
            // 
            // lblQ9
            // 
            this.lblQ9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ9.AutoSize = true;
            this.lblQ9.Location = new System.Drawing.Point(124, 385);
            this.lblQ9.Name = "lblQ9";
            this.lblQ9.Size = new System.Drawing.Size(69, 25);
            this.lblQ9.TabIndex = 40;
            this.lblQ9.Text = "label19";
            // 
            // lblQ8
            // 
            this.lblQ8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ8.AutoSize = true;
            this.lblQ8.Location = new System.Drawing.Point(124, 342);
            this.lblQ8.Name = "lblQ8";
            this.lblQ8.Size = new System.Drawing.Size(69, 25);
            this.lblQ8.TabIndex = 39;
            this.lblQ8.Text = "label18";
            // 
            // lblQ7
            // 
            this.lblQ7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ7.AutoSize = true;
            this.lblQ7.Location = new System.Drawing.Point(124, 297);
            this.lblQ7.Name = "lblQ7";
            this.lblQ7.Size = new System.Drawing.Size(69, 25);
            this.lblQ7.TabIndex = 38;
            this.lblQ7.Text = "label17";
            // 
            // lblQ6
            // 
            this.lblQ6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ6.AutoSize = true;
            this.lblQ6.Location = new System.Drawing.Point(124, 251);
            this.lblQ6.Name = "lblQ6";
            this.lblQ6.Size = new System.Drawing.Size(69, 25);
            this.lblQ6.TabIndex = 37;
            this.lblQ6.Text = "label16";
            // 
            // lblQ5
            // 
            this.lblQ5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ5.AutoSize = true;
            this.lblQ5.Location = new System.Drawing.Point(124, 207);
            this.lblQ5.Name = "lblQ5";
            this.lblQ5.Size = new System.Drawing.Size(69, 25);
            this.lblQ5.TabIndex = 36;
            this.lblQ5.Text = "label15";
            // 
            // lblQ4
            // 
            this.lblQ4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ4.AutoSize = true;
            this.lblQ4.Location = new System.Drawing.Point(124, 163);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(69, 25);
            this.lblQ4.TabIndex = 35;
            this.lblQ4.Text = "label14";
            // 
            // lblQ3
            // 
            this.lblQ3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ3.AutoSize = true;
            this.lblQ3.Location = new System.Drawing.Point(124, 116);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(69, 25);
            this.lblQ3.TabIndex = 34;
            this.lblQ3.Text = "label13";
            // 
            // lblQ2
            // 
            this.lblQ2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ2.AutoSize = true;
            this.lblQ2.Location = new System.Drawing.Point(124, 74);
            this.lblQ2.Name = "lblQ2";
            this.lblQ2.Size = new System.Drawing.Size(69, 25);
            this.lblQ2.TabIndex = 33;
            this.lblQ2.Text = "label12";
            // 
            // lblQ1
            // 
            this.lblQ1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblQ1.AutoSize = true;
            this.lblQ1.Location = new System.Drawing.Point(124, 24);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(69, 25);
            this.lblQ1.TabIndex = 32;
            this.lblQ1.Text = "label11";
            this.lblQ1.Click += new System.EventHandler(this.lblQ1_Click);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(69, 431);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 25);
            this.label10.TabIndex = 30;
            this.label10.Text = "Q10";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(69, 385);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 25);
            this.label9.TabIndex = 29;
            this.label9.Text = "Q9";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(69, 342);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 25);
            this.label8.TabIndex = 28;
            this.label8.Text = "Q8";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 297);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 25);
            this.label7.TabIndex = 27;
            this.label7.Text = "Q7";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(69, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 25);
            this.label4.TabIndex = 26;
            this.label4.Text = "Q4";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(69, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 25);
            this.label6.TabIndex = 25;
            this.label6.Text = "Q6";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 25);
            this.label3.TabIndex = 24;
            this.label3.Text = "Q3";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(69, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 25);
            this.label5.TabIndex = 23;
            this.label5.Text = "Q5";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 25);
            this.label2.TabIndex = 31;
            this.label2.Text = "Q2";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 25);
            this.label1.TabIndex = 22;
            this.label1.Text = "Q1";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(820, 24);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(182, 33);
            this.comboBox1.TabIndex = 50;
            // 
            // frmExam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 517);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.comboBox10);
            this.Controls.Add(this.comboBox9);
            this.Controls.Add(this.comboBox8);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.lblQ10);
            this.Controls.Add(this.lblQ9);
            this.Controls.Add(this.lblQ8);
            this.Controls.Add(this.lblQ7);
            this.Controls.Add(this.lblQ6);
            this.Controls.Add(this.lblQ5);
            this.Controls.Add(this.lblQ4);
            this.Controls.Add(this.lblQ3);
            this.Controls.Add(this.lblQ2);
            this.Controls.Add(this.lblQ1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmExam";
            this.Text = "frmExam";
            this.Load += new System.EventHandler(this.frmExam_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnSubmit;
        private ComboBox comboBox10;
        private ComboBox comboBox9;
        private ComboBox comboBox8;
        private ComboBox comboBox7;
        private ComboBox comboBox6;
        private ComboBox comboBox5;
        private ComboBox comboBox4;
        private ComboBox comboBox3;
        private ComboBox comboBox2;
        private Label lblQ10;
        private Label lblQ9;
        private Label lblQ8;
        private Label lblQ7;
        private Label lblQ6;
        private Label lblQ5;
        private Label lblQ4;
        private Label lblQ3;
        private Label lblQ2;
        private Label lblQ1;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label4;
        private Label label6;
        private Label label3;
        private Label label5;
        private Label label2;
        private Label label1;
        private ComboBox comboBox1;
    }
}